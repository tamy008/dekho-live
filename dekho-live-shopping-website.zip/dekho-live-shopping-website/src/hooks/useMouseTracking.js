
import { useState, useEffect } from 'react';

export const useMouseTracking = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    let animationId = null;
    let lastUpdate = 0;
    let isTracking = true;
    
    const handleMouseMove = (e) => {
      try {
        if (!isTracking || !e) return;
        
        const now = Date.now();
        if (now - lastUpdate < 1000) return;
        
        if (animationId) {
          cancelAnimationFrame(animationId);
          animationId = null;
        }
        
        animationId = requestAnimationFrame(() => {
          try {
            if (!isTracking) return;
            
            const clientX = typeof e.clientX === 'number' ? e.clientX : 0;
            const clientY = typeof e.clientY === 'number' ? e.clientY : 0;
            
            const x = Math.max(0, Math.min(10, Math.round(clientX / 200)));
            const y = Math.max(0, Math.min(10, Math.round(clientY / 200)));
            
            setMousePosition(prev => {
              if (prev?.x === x && prev?.y === y) return prev;
              return { x, y };
            });
            
            lastUpdate = now;
          } catch (innerError) {
            // Silent error handling
          } finally {
            animationId = null;
          }
        });
      } catch (error) {
        if (animationId) {
          cancelAnimationFrame(animationId);
          animationId = null;
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    return () => {
      isTracking = false;
      if (animationId) {
        cancelAnimationFrame(animationId);
        animationId = null;
      }
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return mousePosition;
};
